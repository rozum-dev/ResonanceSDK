//
//  CResonanceUtils.h
//
//  Copyright (c) 2015 Certona. All rights reserved.
//

@import Foundation;

NSString* CPercentEscapedQueryStringKeyFromStringWithEncoding(NSString* string, NSStringEncoding encoding);
NSString* CPercentEscapedQueryStringValueFromStringWithEncoding(NSString* string, NSStringEncoding encoding);
